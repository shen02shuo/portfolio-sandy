# Shuo Shen — Sound Designer Portfolio

Minimal, static, responsive portfolio for GitHub Pages. No build tools required.

## Setup
1. Create a **public** GitHub repository with a non-obvious name, e.g. `portfolio-k7m92x`.
2. Upload all files in this folder to the repository root, including `.nojekyll`.
3. Settings → Pages → Deploy from a branch → `main` / `(root)` → Save.
4. Visit `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`.

## Customize
- `index.html`: biography, name, contact email, section headings.
- `projects.js`: replace placeholder project titles/descriptions and add `goal`, `approach`, `implementation`, `experience`, `tools` to each project.
- To embed an unlisted YouTube video, add `youtubeId:'VIDEO_ID'` to a project object in `projects.js`.
- Add your own project thumbnail support by customizing the `.thumb` markup in `script.js` (or ask for help).
- Add `assets/resume.pdf` and remove the resume placeholder click handler in `script.js`.
- `style.css`: design and responsive styling.

## Privacy caveats
`noindex` is a request to search engines, not access control. A public GitHub repository and its files remain public. Links can be forwarded. Never publish confidential or NDA-protected content. YouTube Unlisted videos can be viewed by anyone with the video link.

## Credits
All project content is placeholder copy. Do not present it as completed professional experience until replaced with your actual work.
