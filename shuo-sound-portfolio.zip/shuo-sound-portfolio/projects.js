// Replace placeholder projects with your actual work. Add an optional YouTube video ID to embed an unlisted video.
window.PORTFOLIO_PROJECTS = [
 {slug:'game-sound-design',title:'In-Game Sound Design',category:'Game Audio · Sound Design',section:'featured',description:'A case study of sound design for actions, animation, and interactive events.'},
 {slug:'gameplay-feedback',title:'Gameplay Feedback Audio',category:'Combat · Player Feedback',section:'featured',description:'Sound cues that communicate timing, impact, and gameplay information.'},
 {slug:'environmental-audio',title:'Environmental & Spatial Audio',category:'Ambience · Spatial Sound',section:'featured',description:'Creating atmosphere and spatial clarity through layered environmental audio.'},
 {slug:'interactive-music',title:'Interactive Music System',category:'Adaptive Music · Transitions',section:'featured',description:'A responsive music system with states, layers, and transitions.'},
 {slug:'audio-implementation',title:'Audio Implementation',category:'Wwise / FMOD / Game Engine',section:'featured',description:'An implementation-focused case study of game audio logic.'},
 {slug:'pure-data',title:'Interactive Sound Experiment',category:'Pure Data · Creative Technology',section:'experiments',description:'An experimental real-time interactive sound system built with Pure Data.'}
];
